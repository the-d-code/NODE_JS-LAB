$(()=>{
    $("#button1").click(()=>{
        $.ajax({
            url: 'http://localhost:8000/validate',
            type: 'POST',
            cache: false,
            //headers:{},
            data: {
              username: $('#username').val(),
              password: $('#password').val()
            },
            success: function (data) {
              // $('#error-group').css('display', 'none');
              console.log(data)
              alert('Your submission was successful ');

            },
            error: function (data) {
              //$('#error-group').css('display', 'block');
              var errors = JSON.parse(data.responseText);
              //var errorsContainer = $('#errors');
              //errorsContainer.innerHTML = '';
              $("#err").html("")
              var errorsListStr = '';
        
              for (var i = 0; i < errors.length; i++) {
                errorsListStr +=  errors[i].msg + '<br>';
              }
              $("#err").html(errorsListStr);
            }
          });
         
    });
});