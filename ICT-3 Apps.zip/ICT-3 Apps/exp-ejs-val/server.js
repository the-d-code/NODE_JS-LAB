const express=require("express")
const app=express();
const {check,validationResult}=require("express-validator")

const cors=require("cors")
const path = require('path');
app.use(express.urlencoded({extended: false}))
//app.use(express.json())
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.use(cors())
app.get("/",(req,res)=>{
    res.render("form1")
})

// app.post("/validate",(req,res)=>{
//     var errors=[];
//     if(req.body.username=="")
//     {
//         errors.push("Enter username.")
//     }
//     if(req.body.password=="")
//     {
//         errors.push("Enter password.")
//     }
//     if(errors.length!=0)
//     {
//         res.render("form1",{errors: errors})
//     }
//     else    
//         res.send(req.body.username+" "+req.body.password)
    
// })

app.post("/validate",    
    [
        check("username","Username should not be empty.").notEmpty() ,
        check("password","Password should not be empty.").notEmpty()
    ],
    (req,res)=>{
        console.log(req.body)
//        res.send(req.body)
        const errors=validationResult(req)
        if(!errors.isEmpty())
        {
            console.log(errors)
            return res.status(422).json(errors.array());
            //res.render("form1",{errors: errors})
        }
        else
        {
            res.send({})    
        }
    })
app.listen(8000)