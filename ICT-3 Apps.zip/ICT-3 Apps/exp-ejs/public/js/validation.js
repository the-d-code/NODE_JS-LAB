// $("document").ready(()=>{
//     $("#button1").click(()=>{
//         $.ajax({
//             type:"POST",
//             url:"/validate",
//             data: {},
//             success: (data)=>{}

//         })
//     })
// })


$(()=>{
    $('#button1').click(function () {
        //alert("click")

        var data= {
            name1: $('#name1').val(),
            email: $('#email').val(),
            mobile: $('#mobile').val(),
            password: $('#password').val(),
            confirmPassword: $('#cpassword').val()
        }
        console.log(data)
        
        $.ajax({
        url: '/validate',
        type: 'POST',
        //headers:{},
        data: {
            name1: $('#name1').val(),
            email: $('#email').val(),
            mobile: $('#mobile').val(),
            password: $('#password').val(),
            confirmPassword: $('#cpassword').val()
        },
        success: function () {
            //$('#error-group').css('display', 'none');
            $('#err').html("")
            alert('Your submission was successful');
        },
        error: function (data) {
            //alert("error")
            console.log(data)
            //$('#error-group').css('display', 'none');
            $('#err').html("")
            //alert(data)
            //$('#error-group').css('display', 'block');
            var errors = JSON.parse(data.responseText);
            var errorsContainer = $('#err');
            errorsContainer.innerHTML = '';
            var errorsListStr = '';
    
            for (var i = 0; i < errors.length; i++) {
              errorsListStr +=  errors[i].msg + '<br>';
            }
            errorsContainer.html(errorsListStr);
        }
        });
    });
});