var express = require('express');
var app = express();
const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({extended: true}))

const {check, validationResult} = require('express-validator');

// set the view engine to ejs
app.set('view engine', 'ejs');

// use res.render to load up an ejs view file

// index page
app.get('/', function(req, res) {
  res.render('index');
});

// about page
app.get('/about', function(req, res) {
  res.render('about');
});
app.get("/form",(req,res)=>{
  res.render("form1")
})
app.post("/add",(req,res)=>{
  res.send(req.body.hobbies.join(","))
  console.log(req.body.hobbies)
})
app.get('/page1', function(req, res) {
    var var1 = "Var1";
    var emp_arr = [
      { name: 'Emp1', company: "Amazon"},
      { name: 'Emp2', company: "LinkedIn"},
      { name: 'Emp3', company: "ThoughtWorks"}
    ];
    
    res.render('page1', {
        emp_arr: emp_arr,
        var1: var1
    });
  });
  app.get("/form1",(req,res)=>{
    res.render("form1")
  })

 app.get("/form2",(req,res)=>{
  res.render("form2")
 })

 app.post("/form2_process",[
  check('fname').trim().escape().notEmpty().withMessage("Enter fname"),
  check('lname').trim().escape().notEmpty().withMessage("Enter lname")
],(req,res)=>{
  const errors = validationResult(req);
  console.log(errors)
  if(!errors.isEmpty())
  {
    res.render("form2",{errors:errors.array()})
  }
  else
    res.send(req.body.fname+" "+req.body.lname)
 })


  app.post("/form1_process",
    [
    //Validate and sanitize
      check('fname').trim().escape().notEmpty().withMessage("Enter fname"),
      check('lname').trim().escape().notEmpty().withMessage("Enter lname")
    ],
    (req,res)=>{
      const errors = validationResult(req);
      console.log(errors);
      
      if (!errors.isEmpty()) {
        res.render("form1",{errors:errors.array()})
      } else {
        res.send({});
      }
  
  })

  app.get("/page2",(req,res)=>{
    res.render("page2");
  })


  app.post('/validate', 
    [
    //Validate and sanitize
      check('name1').trim().escape().notEmpty().withMessage("Enter name").isLength({min: 5}).withMessage('Name must have more than 5 characters'),
      check('email', 'Your email is not valid').isEmail().normalizeEmail(),
      check('mobile', 'Enter mobile number ').not().isEmpty(),
      check('password', 'Enter password').not().isEmpty(),
      check('confirmPassword', 'Passwords do not match').custom((value, {req}) => (value === req.body.password))
    ],

  function (req, res) {
      //res.send("name1="+req.body.name1)
      const errors = validationResult(req);
      console.log(errors);
  
      if (!errors.isEmpty()) {
        return res.status(422).json(errors.array());
      } else {
        res.send({});
      }
    });
  
  app.listen(8000);
console.log('Server is listening on port 8000');