const express = require('express');  
const app = express();
// const session=require("express-session")

const cookieParser=require("cookie-parser")
app.use(cookieParser())
require("dotenv").config();
const jwt= require("./libs/jwt")
const morgan=require("morgan")
app.use(morgan("combined"))
const helmet=require("helmet")
app.use(helmet())

// app.use(session({
// 	secret: 'secret',
// 	resave: false,
// 	saveUninitialized: false
// }));


app.use(express.urlencoded({ extended: true }));

// app.post("/login",(req,res)=>{
//     if(req.body.uname=="uname1" && req.body.password=="pass")
//     {
//         req.session.loggedin = true;
//         req.session.username = req.body.uname;
//         res.send("Logged in")
//     }
//     else
//         return res.status(404).send("");
// })
// function validate_session(req,res,next){
//     if(req.session.loggedin==true && req.session.username!="")
//         next()
//     else
//         return res.status(500).send("Access Denied");
// }
app.get("/gettoken", jwt.sign)
var BookRoute=require("./routes/BookRoute")
app.use("/books",jwt.verify,BookRoute);
//app.use("/books",validate_session,BookRoute);

app.listen(8000);
