const mongoose = require("mongoose");

const userSchemas = new mongoose.Schema({
  username: String,
  password: String,
  role: Object,
});

module.exports = mongoose.model("users", userSchemas);
